

<?php $__env->startSection('title', 'Mode of Payment| '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-plus"></i> Add Mode of Payment</h1>
            <p class="text-muted">Create a new payment method to simplify transactions.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Mode of Payment</li>
            <li class="breadcrumb-item"><a href="#">Add Mode of Payment</a></li>
        </ul>
    </div>

    <div class="">
        <a class="btn btn-primary" href="<?php echo e(route('modeofpayment.index')); ?>">
            <i class="fa fa-edit"> </i> Manage Mode of Payment
        </a>
    </div>
    
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="tile">
                <h3 class="tile-title">Mode of Payment</h3>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="tile-body">
                    <form method="POST" action="<?php echo e(route('modeofpayment.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label class="control-label">Name</label>
                                <input type="text" id="name" name="name" placeholder="Enter Name" oninput="toggleTermDropdown()" value="<?php echo e(old('name')); ?>" class="form-control" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            

                            <div id="term-container" style="display: none;">
                                <label for="term">Payment Term</label>
                                <select name="term" id="term" class="form-control col-md-20">
                                    <option value="30">30 days</option>
                                    <option value="45">45 days</option>
                                    <option value="90">90 days</option>
                                    <option value="60">60 days</option>
                                    <option value="120">120 days</option>
                                </select>
                            </div>

                             <div class="form-group col-md-6">
                                <label class="control-label">Description</label>
                                <input type="text" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           
                            <div class="form-group col-md-12 mt-3">
                                <button class="btn btn-success float-right" type="submit">
                                    <i class="fa fa-fw fa-lg fa-check-circle"></i> Add Mode of Payment 
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
function toggleTermDropdown() {
    const nameValue = document.getElementById('name').value.trim().toLowerCase();
    const termContainer = document.getElementById('term-container');
    
    if (nameValue === 'pdc/check') {
        termContainer.style.display = 'block';
    } else {
        termContainer.style.display = 'none';
    }
}

// Call once on page load in case form is prefilled (e.g. after validation errors)
document.addEventListener('DOMContentLoaded', () => {
    toggleTermDropdown();
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/modeofpayment/create.blade.php ENDPATH**/ ?>