

<?php $__env->startSection('title', 'Supplier Report | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="app-content">
        <div class="app-title d-flex justify-content-between align-items-center">
            <div>
                <h1><i class="fa fa-th-list"></i> Supplier Report</h1>
                <p class="text-muted mb-0">
                    View a detailed list of all Suppliers with filters by status (active or inactive) 
                    and registration date range. Use this report to monitor suppliers records, 
                    track account activity, and export results to Excel for analysis.
                </p>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-12">
                <div class="tile shadow-sm">
                    <h3 class="tile-title mb-3"><i class="fa fa-bar-chart"></i> Supplier Report</h3>
                    <div class="tile-body">
                        <div class="container">
                            
                            <form method="GET" action="<?php echo e(route('reports.supplier_report')); ?>" class="row g-4 mb-4">
                                <div class="col-md-3">
                                    <select name="status" class="form-control">
                                        <option value="">-- Select Status --</option>
                                        <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                                </div>
                                <div class="col-md-2">
                                    <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                                </div>
                                <div class="col-md-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary me-2">Filter</button>
                                    <a href="<?php echo e(route('reports.supplier_report_export', request()->all())); ?>" 
                                        class="btn btn-success">
                                        <i class="fa fa-file-excel-o"></i> Export
                                    </a>
                                </div>
                            </form>

                            
                            <div class="table-responsive mt-3">
                                <table class="table table-bordered table-striped" id="supplierReportTable">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Supplier ID</th>
                                            <th>Supplier Code</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Status</th>
                                            <th>Date Registered</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($supplier->id); ?></td>
                                                <td><?php echo e($supplier->supplier_code); ?></td>
                                                <td><?php echo e($supplier->name); ?></td>
                                                <td><?php echo e($supplier->email); ?></td>
                                                <td><?php echo e($supplier->mobile); ?></td>
                                                <td>
                                                    <span class="badge <?php echo e($supplier->status ? 'bg-success' : 'bg-danger'); ?>">
                                                        <?php echo e($supplier->status ? 'Active' : 'Inactive'); ?>

                                                    </span>
                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($supplier->created_at)->format('M d, Y')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No suppliers found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('/')); ?>js/plugins/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('/')); ?>js/plugins/dataTables.bootstrap.min.js"></script>
<script>
    $('#supplierReportTable').DataTable({
        "order": [[0, 'asc']],
        "paging": true,
        "searching": true,
        "info": true
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/reports/supplier_report.blade.php ENDPATH**/ ?>