

<?php $__env->startSection('title', 'Adjustment Collection | AVT Hardware'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-exchange"></i> Adjustment Collection Records</h1>
                <p class="text-muted mb-0">Review, update, or delete collection adjustment entries.</p>
            </div>
            <ul class="app-breadcrumb breadcrumb side">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item">Collection Adjustment</li>
                <li class="breadcrumb-item active"><a href="#">Adjustment Records</a></li>
            </ul>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <a class="btn btn-primary" href="<?php echo e(route('adjustment_collection.create')); ?>">
                <i class="fa fa-plus"></i> New Adjustment Entry
            </a>
        </div>

        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="row mt-2">
            <div class="col-md-12">
                <div class="tile">
                    <h3 class="tile-title mb-3"><i class="fa fa-table"></i> Adjustment Collection Table</h3>
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="adjustmentTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Adjustment #</th>
                                    <th>Invoice #</th>
                                    <th>Debit/Credit</th>
                                    <th>Collection Date Adjustment</th>
                                    <th>Account Name</th>
                                    <th>Adjusted Amount</th>
                                    <th>Remarks</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $adjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="badge badge-info"><?php echo e($adjustment->adjustment_no); ?></span></td>
                                        <td><?php echo e($adjustment->invoice_no); ?></td>
                                        <td>
                                            <span class="badge 
                                                <?php echo e($adjustment->entry_type === 'Debit' ? 'badge-success' : 'badge-danger'); ?>">
                                                <?php echo e($adjustment->entry_type); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($adjustment->collection_date_adjustment)->format('M d, Y')); ?></td>
                                        <td><?php echo e($adjustment->account_name); ?></td>
                                        <td><?php echo e($adjustment->amount); ?></td>
                                        <td><?php echo e($adjustment->remarks ?? '-'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('adjustment_collection.edit', $adjustment->id)); ?>" class="btn btn-info btn-sm">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('adjustment_collection.destroy', $adjustment->id)); ?>" method="POST" class="d-inline delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/dataTables.bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
    <script type="text/javascript">
        $('#adjustmentTable').DataTable();

        // SweetAlert delete confirmation
        $(document).on('click', '.btn-delete', function(e) {
            e.preventDefault();
            let form = $(this).closest('form');
            Swal.fire({
                title: 'Are you sure?',
                text: "This adjustment entry will be permanently deleted.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/collection/adjustment_collection/index.blade.php ENDPATH**/ ?>