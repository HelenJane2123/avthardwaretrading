

<?php $__env->startSection('titel', 'Supplier Products | '); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">

    <div class="app-title d-flex justify-content-between align-items-center">
        <div>
            <h1><i class="fa fa-building text-primary"></i> Supplier: <strong><?php echo e($supplier->name); ?></strong></h1>
            <p class="text-muted mb-0">Here is the list of all items supplied by <strong><?php echo e($supplier->name); ?></strong>.</p>
        </div>
        <div>
            <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-outline-secondary">
                <i class="fa fa-arrow-left"></i> Back to List
            </a>
            <a href="<?php echo e(route('supplier.supplier-products.export', $supplier->id)); ?>" class="btn btn-success">
                <i class="fa fa-file-excel-o"></i> Export to Excel
            </a>
        </div>
    </div>

    <div class="tile mb-4">
        <div class="tile-body">
            <h5 class="text-dark mb-3">Supplier Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Code:</strong> <?php echo e($supplier->supplier_code); ?></p>
                    <p><strong>Address:</strong> <?php echo e($supplier->address); ?></p>
                    <p><strong>Contact:</strong> <?php echo e($supplier->mobile); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Email:</strong> <?php echo e($supplier->email); ?></p>
                    <p><strong>Tax:</strong> <?php echo e($supplier->tax); ?></p>
                    <p><strong>Details:</strong> <?php echo e($supplier->details); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="tile">
        <div class="tile-body">
            <h5 class="text-dark mb-3">Product List</h5>
            <div class="table-responsive">
               <table class="table table-hover table-bordered" id="productsTable">
                    <thead class="thead-light">
                        <tr class="bg-light">
                            <th>Image</th>
                            <th>Item Code</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Unit</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Volume Less</th>
                            <th>Regular Less</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $supplier->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($item->item_image): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->item_image)); ?>" width="60" class="img-thumbnail">
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->item_code); ?></td>
                                <td><?php echo e($item->category->name ?? 'N/A'); ?></td>
                                <td><?php echo e($item->item_description); ?></td>
                                <td><?php echo e($item->unit->name ?? 'N/A'); ?></td>
                                <td><?php echo e($item->item_qty); ?></td>
                                <td>₱<?php echo e(number_format($item->item_price, 2)); ?></td>
                                <td><?php echo e($item->volume_less); ?></td>
                                <td><?php echo e($item->regular_less); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">No products available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if($supplier->items->isNotEmpty()): ?>
                    <!-- <tfoot>
                        <tr class="bg-light font-weight-bold">
                            <td colspan="5" class="text-end">TOTAL</td>
                            <td>
                                <?php echo e($supplier->items->sum('item_qty')); ?>

                            </td>
                            <td>
                                ₱<?php echo e(number_format($supplier->items->sum('item_price'), 2)); ?>

                            </td>
                            <td>
                                ₱<?php echo e(number_format($supplier->items->sum('item_amount'), 2)); ?>

                            </td>
                        </tr>
                    </tfoot> -->
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#productsTable').DataTable();</script>
    <script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/supplier/supplier-products.blade.php ENDPATH**/ ?>