<div class="details" style="margin-bottom: 20px;">

    <!-- Purchase & Supplier Info Side by Side -->
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">

        <!-- Purchase Info (Left) -->
        <div style="width: 48%;">
            <h4 style="margin-bottom: 8px; border-bottom: 1px solid #000;">Purchase Info</h4>
            <p><strong>PO Number:</strong> <?php echo e($purchase->po_number); ?></p>
            <p><strong>Salesman:</strong> <?php echo e($purchase->salesman['salesman_name']); ?></p>
            <p><strong>Date Purchased:</strong> <?php echo e(\Carbon\Carbon::parse($purchase->date)->format('F d, Y')); ?></p>
        </div>

        <!-- Supplier Info (Right) -->
        <div style="width: 48%;">
            <h4 style="margin-bottom: 8px; border-bottom: 1px solid #000;">Supplier Info</h4>
            <p><strong>Name:</strong> <?php echo e($purchase->supplier->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($purchase->supplier->email ?? 'N/A'); ?></p>
            <p><strong>Phone:</strong> <?php echo e($purchase->supplier->phone ?? 'N/A'); ?></p>
            <p><strong>Address:</strong> <?php echo e($purchase->supplier->address ?? 'N/A'); ?></p>
        </div>

    </div>
</div>

<hr>

<!-- Purchase Items in Table -->
<h4 style="margin-top: 20px; margin-bottom: 10px;">Purchase Items</h4>
<table width="100%" border="1" cellspacing="0" cellpadding="6" style="border-collapse: collapse; font-size: 13px;">
    <thead style="background: #f2f2f2;">
        <tr>
            <th style="text-align: left;">Product Code</th>
            <th style="text-align: left;">Description</th>
            <th style="text-align: center;">Quantity</th>
            <th style="text-align: center;">Discount</th>
            <th style="text-align: right;">Price</th>
            <th style="text-align: right;">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product_code); ?></td>
                <td><?php echo e($item->supplierItem->item_description ?? 'N/A'); ?></td>
                <td style="text-align: center;"><?php echo e($item->qty); ?></td>
                <td style="text-align: center;">Less <?php echo e($item->discount); ?>%</td>
                <td style="text-align: right;">₱<?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td style="text-align: right;">₱<?php echo e(number_format($item->total, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table width="100%" style="margin-top: 30px;">
    <tr>
        <!-- Comments / Special Instructions -->
        <td width="60%" valign="top" style="padding-right: 20px; border: none !important;">
            <strong>Comments or Special Instructions:</strong><br>
            <div style="border: 1px solid #000; min-height: 80px; padding: 10px;">
                <?php echo e($purchase->remarks ?? ''); ?>

            </div>
        </td>
        <td width="80%" valign="top" style="border: none !important;float:right;">
            <table class="totals">
                <tr>
                    <td><strong>SUBTOTAL: </strong></td>
                    <td><?php echo e(number_format($purchase->subtotal, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>TAX/DISCOUNT: </strong></td>
                    <td><?php echo e($purchase->discount_value); ?></td>
                </tr>
                <tr>
                    <td><strong>SHIPPING: </strong></td>
                    <td><?php echo e(number_format($purchase->shipping, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>OTHER: </strong></td>
                    <td><?php echo e(number_format($purchase->other_charges, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>TOTAL: </strong></td>
                    <td><strong><?php echo e(number_format($purchase->grand_total, 2)); ?></strong></td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<table width="100%" style="margin-top: 20px; border: 1px solid #000; border-collapse: collapse;">
    <tr style="background-color: #004080; color: #fff;">
        <th colspan="4" style="padding: 8px; text-align: left;">PAYMENT SUMMARY</th>
    </tr>
    <tr>
        <?php
            $totalPaid= $purchase->payments->sum('amount_paid');
            $outstanding = $purchase->grand_total - $totalPaid;

            if ($totalPaid == 0) {
                $status = 'none'; // No payment yet
            } elseif ($totalPaid < $purchase->grand_total) {
                $status = 'partial';
            } else {
                $status = 'paid';
            }
        ?>
        <td><strong>Total Amount:</strong></td>
        <td>₱<?php echo e(number_format($purchase->grand_total, 2)); ?></td>
        <td><strong>Total Paid:</strong></td>
        <td>₱<?php echo e(number_format($totalPaid, 2)); ?></td>
    </tr>
    <tr>
        <td><strong>Outstanding Balance:</strong></td>
        <td>₱<?php echo e(number_format($outstanding, 2)); ?></td>
        <td><strong>Status:</strong></td>
        <td style="font-weight:bold; color:
            <?php echo e($status === 'Fully Paid' ? 'green' : ($status === 'Partial Payment' ? 'orange' : 'red')); ?>">
            <?php echo e($status); ?>

        </td>
    </tr>
</table>


<?php if($purchase->payments->count() > 0): ?>
    <table width="100%" style="margin-top: 15px; border: 1px solid #000; border-collapse: collapse;">
        <tr style="background-color: #004080; color: #fff;">
            <th colspan="4" style="padding: 8px; text-align: left;">PAYMENT HISTORY</th>
        </tr>
        <tr>
            <th style="width: 20%;">Date</th>
            <th style="width: 30%;">Amount Paid</th>
            <th style="width: 25%;">Outstanding Balance</th>
            <th style="width: 25%;">Payment Status</th>
        </tr>
        <?php $__currentLoopData = $purchase->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('m/d/Y')); ?></td>
                <td>₱<?php echo e(number_format($payment->amount_paid, 2)); ?></td>
                <td>₱<?php echo e(number_format($payment->outstanding_balance, 2)); ?></td>
                <td><?php echo e(ucfirst($payment->payment_status)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <p style="margin-top: 15px; font-style: italic;">No payments recorded yet.</p>
<?php endif; ?>
<?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/purchase/partial/details.blade.php ENDPATH**/ ?>