

<?php $__env->startSection('title', 'Collection Report | '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">
    <div class="app-title d-flex justify-content-between align-items-center">
        <div>
            <h1><i class="fa fa-money-bill-wave"></i> Collection Report</h1>
            <p class="text-muted mb-0">
                View all collected payments from customers within a selected date range. 
                Filter by salesman, customer, or product to track collections, monitor performance, 
                and analyze payment trends.
            </p>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12">
            <div class="tile shadow-sm">
                <h3 class="tile-title mb-3"><i class="fa fa-list"></i> Collection Transactions</h3>
                <div class="tile-body">
                    <div class="container">
                        
                        <form method="GET" action="<?php echo e(route('reports.collection_report')); ?>" class="row g-3 mb-4">
                            <div class="col-md-3">
                                <label for="start_date" class="form-label">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                            </div>
                            <div class="col-md-3">
                                <label for="end_date" class="form-label">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                            </div>
                            <div class="col-md-2">
                                <label for="salesman" class="form-label">Salesman</label>
                                <select name="salesman" id="salesman" class="form-control">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $salesmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($salesman->salesman); ?>" <?php echo e(request('salesman') == $salesman->salesman ? 'selected' : ''); ?>>
                                            <?php echo e($salesman->salesman); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="customer_id" class="form-label">Customer</label>
                                <select name="customer_id" id="customer_id" class="form-control">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->id); ?>" <?php echo e(request('customer_id') == $customer->id ? 'selected' : ''); ?>>
                                            <?php echo e($customer->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="product_id" class="form-label">Product</label>
                                <select name="product_id" id="product_id" class="form-control">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>" <?php echo e(request('product_id') == $product->id ? 'selected' : ''); ?>>
                                            <?php echo e($product->product_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12 d-flex justify-content-end align-items-end mt-2">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fa fa-filter"></i> Filter
                                </button>
                                <a href="<?php echo e(route('reports.collection_report_export', request()->all())); ?>" class="btn btn-success">
                                    <i class="fa fa-file-excel-o"></i> Export
                                </a>
                            </div>
                        </form>

                        
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered table-striped" id="collectionTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Collection #</th>
                                        <th>Date</th>
                                        <th>Customer</th>
                                        <th>Invoice Number</th>
                                        <th>Salesman</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Amount Collected(₱)</th>
                                        <th>Adjustment</th>
                                        <th>Adjustment Name</th>
                                        <th>Adjustment Date</th>
                                        <th>Adjustment Amount</th>
                                        <th>Adjustment Remarks</th>
                                        <th>Payment Mode</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($collection->collection_number); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($collection->collection_date)->format('M d, Y')); ?></td>
                                            <td><?php echo e($collection->customer_name); ?></td>
                                            <td><?php echo e($collection->invoice_number); ?></td>
                                            <td><?php echo e($collection->salesman); ?></td>
                                            <td><?php echo e($collection->product_name); ?></td>
                                            <td><?php echo e($collection->qty); ?></td>
                                            <td><?php echo e(number_format($collection->amount_collected, 2)); ?></td>
                                            <td><?php echo e($collection->adjustment_type); ?></td>
                                            <td><?php echo e($collection->adjustment_name); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($collection->adjustment_date)->format('M d, Y')); ?></td>
                                            <td><?php echo e(number_format($collection->adjustment_amount, 2)); ?></td>
                                            <td><?php echo e($collection->adjustment_remarks); ?></td>
                                            <td><?php echo e($collection->payment_mode); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No collections found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $('#collectionTable').DataTable({
        "order": [[1, 'desc']], // Sort by Date
        "paging": true,
        "searching": true,
        "info": true
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/reports/collection_report.blade.php ENDPATH**/ ?>