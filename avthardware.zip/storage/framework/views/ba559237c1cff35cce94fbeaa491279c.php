

<?php $__env->startSection('content'); ?>
<section class="login-wrapper d-flex">

    <!-- Left Side: Login -->
    <div class="login-left d-flex flex-column justify-content-center align-items-center">
        <div class="logo text-left w-100 px-4 d-flex align-items-center mb-4">
            <img src="<?php echo e(asset('images/avt_logo.png')); ?>" alt="Logo" style="height: 130px; margin-right: 15px;">
            <div>
                <h1 class="mb-0">AVT Hardware Trading</h1>
                <h5 class="mb-0">Wholesale of hardware, electricals, & plumbing supply etc.</h5>
            </div>
        </div>

        <div class="login-box px-4 w-100">
            <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                    <i class="fa fa-check-circle"></i>  <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form id="secureLoginForm" class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                
                <input type="text" name="username_confirm" style="display:none">

                <h5 class="login-head mb-4">
                    <i class="fa fa-lg fa-fw fa-user"></i> LOG IN
                </h5>

                
                <div class="form-group">
                    <label for="email" class="control-label">Email <span class="text-danger">*</span></label>
                    <input id="email" type="email"
                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                        placeholder="Enter your email address">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group position-relative">
                    <label for="password" class="control-label">Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input id="password" type="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="password" required autocomplete="current-password" placeholder="Enter your password">
                        <div class="input-group-append">
                            <button type="button" class="btn btn-outline-secondary toggle-password" data-target="#password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group">
                    <div class="utility">
                        <div class="animated-checkbox">
                            <label>
                                <input type="checkbox" name="remember" id="remember">
                                <span class="label-text">Stay signed in</span>
                            </label>
                        </div>
                    </div>
                </div>

                
                

                
                <div class="form-group btn-container">
                    <button id="loginBtn" class="btn btn-primary btn-block" type="submit">
                        <i class="fa fa-sign-in fa-lg fa-fw"></i> LOG IN
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Right Side -->
    <div class="login-right d-flex align-items-center justify-content-center">
        <div class="analytics-text text-white text-center">
            <h2>Track your Sales</h2>
            <p>Real-time Inventory Monitoring & Analytics</p>
            <img src="<?php echo e(asset('images/data-analysis.png')); ?>" alt="Sales Analytics" class="img-fluid mt-4">
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
$(function () {
    // Password visibility toggle
    $('.toggle-password').on('click', function () {
        const input = $($(this).data('target'));
        const icon = $(this).find('i');
        const isHidden = input.attr('type') === 'password';

        input.attr('type', isHidden ? 'text' : 'password');
        icon.toggleClass('fa-eye fa-eye-slash');

        // Auto-hide after 10 seconds for security
        if (isHidden) {
            setTimeout(() => {
                input.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }, 10000);
        }
    });

    // Disable login button during submission
    $('#secureLoginForm').on('submit', function () {
        $('#loginBtn').prop('disabled', true)
                      .html('<i class="fa fa-spinner fa-spin"></i> Logging in...');
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/auth/login.blade.php ENDPATH**/ ?>