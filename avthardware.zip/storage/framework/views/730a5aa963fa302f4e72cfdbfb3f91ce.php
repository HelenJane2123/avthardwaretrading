

<?php $__env->startSection('title', 'Add Product | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-plus"></i> Add New Product</h1>
                <p class="text-muted mb-0">Create a new product and manage its details in your inventory.</p>
            </div>
            <ul class="app-breadcrumb breadcrumb">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item">Product</li>
                <li class="breadcrumb-item"><a href="#">Add Products</a></li>
            </ul>
        </div>

         <?php if(session()->has('message')): ?>
            <div class="alert alert-success shadow-sm">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger shadow-sm">
                <strong>Whoops!</strong> There were some problems with your input.
                <ul class="mb-0 mt-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>- <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

       
        <div class="mb-3">
            <a class="btn btn-outline-primary" href="<?php echo e(route('product.index')); ?>">
                <i class="fa fa-list"></i> Manage Products
            </a>
        </div>
        <div class="row mt-2">
            <div class="clearix"></div>
            <div class="col-md-12">
                <div class="tile">
                    <?php if(auth()->user()->user_role === 'super_admin'): ?>
                        <hr/>
                        <div class="col-md-12">
                            <div class="tile-body">
                                <h3 class="tile-title">Import Bulk Products</h3>
                                <small class="text-muted">Use this field only to import bulk product items and product supplier details</small>
                                <form action="<?php echo e(route('import.product')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <label>Select Excel File:</label>
                                    <input type="file" name="file" class="form-control" required><br/>
                                    <button type="submit" class="btn btn-primary">Import</button>
                                </form>
                            </div>
                        </div>
                        <hr/>
                    <?php endif; ?>
                    <h3 class="tile-title">Product</h3>
                    <div class="tile-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <!-- Left Column: Image -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="control-label">Image</label>
                                        <i class="fa fa-image fa-5x text-muted mb-2"></i>
                                        <div class="form-group mt-2">
                                            <label>Change Image</label>
                                            <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        </div>
                                        <!-- <input name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"> -->
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        
                                        <?php if(isset($product) && $product->image): ?>
                                            <div class="mt-2">
                                                <img src="<?php echo e(asset('storage/'.$product->image)); ?>" 
                                                    alt="Product Image" 
                                                    class="img-thumbnail" 
                                                    style="max-width: 100%; height: auto;">
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Right Column: Product Details -->
                                <div class="col-md-9">
                                    <div class="row">
                                        <div class="form-group col-md-4 position-relative">
                                            <label class="control-label">Product</label>
                                            <input type="text" id="product_name" name="product_name" class="form-control" placeholder="Search product...">
                                            <div id="productSuggestions" class="list-group" style="display:none; position:absolute; z-index:1000;"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label">Product Code</label>
                                            <input name="product_code" id="product_code" class="form-control" type="text" value="<?php echo e($product_code); ?>" readonly>
                                            <!-- <input name="product_code" id="product_code" class="form-control" type="text" readonly> -->
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label">Supplier Product Code</label>
                                            <input name="supplier_product_code" id="supplier_product_code" class="form-control" type="text" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label fw-bold">Product Description</label>
                                            <textarea name="description"
                                                class="form-control"
                                                rows="2"></textarea>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label fw-bold">Volume Less</label>
                                            <textarea name="volume_less"
                                                class="form-control"
                                                rows="2"></textarea>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label fw-bold">Regular Less</label>
                                            <textarea name="regular_less"
                                                class="form-control"
                                                rows="2"></textarea>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label">Serial Number</label>
                                            <input name="serial_number" class="form-control <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" placeholder="Enter Serial Number">
                                            <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label">Category</label>
                                            <select name="category_id" class="form-control">
                                                <option>---Select Category---</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label">Model</label>
                                            <input name="model" class="form-control <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Enter Model">
                                            <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label">Initial Quantity</label>
                                            <input name="quantity" class="form-control" type="number" min="0" placeholder="Enter Initial Stock">
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label">Remaining Stock</label>
                                            <input name="remaining_stock" id="remaining_stock" class="form-control" type="number" readonly>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label">Selling Price</label>
                                            <input name="sales_price" class="form-control <?php $__errorArgs = ['sales_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" placeholder="Enter Selling Price">
                                            <?php $__errorArgs = ['sales_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label">Unit</label>
                                            <select name="unit_id" class="form-control">
                                                <option value="">---Select Unit---</option>
                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="control-label">Discount</label>
                                            <select name="tax_id" class="form-control">
                                                <option value="0">---Select Discount---</option>
                                                <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tax->id); ?>"><?php echo e($tax->name); ?> %</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mt-4">
                                <div class="card-header bg-secondary text-white">
                                    <h6 class="mb-0"><i class="fa fa-exchange-alt"></i> Adjustments</h6>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered table-sm" id="adjustmentTable">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Adjustment</th>
                                                <th>Adjustment Status</th>
                                                <th>Remarks</th>
                                                <th>New Initial Qty</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <input type="number" name="adjustment[]" class="form-control adjustment" value="0" min="0">
                                                </td>
                                                <td>
                                                    <select name="adjustment_status[]" class="form-control">
                                                        <option value="Return">Return</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="adjustment_remarks[]" class="form-control" placeholder="Enter remarks">
                                                </td>
                                                <td>
                                                    <input type="number" name="new_initial_qty[]" class="form-control new-initial-qty" readonly>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                           
                            <div class="card mt-4">
                                <div class="card-header bg-secondary text-white">
                                    <h6 class="mb-0"><i class="fa fa-truck"></i> Supplier Details</h6>
                                </div>
                                <div class="card-body">
                                    <div id="example-2" class="content">
                                        <div class="group row g-3 align-items-end">
                                            <div class="col-md-6">
                                                <label for="supplier_name" class="form-label">Supplier</label>
                                                <input type="text" id="supplier_name" name="supplier_name" 
                                                    class="form-control" autocomplete="off">
                                                <div id="supplierSuggestions" class="list-group shadow-sm"></div>
                                                <input type="hidden" id="supplier_id" name="supplier_id[]">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="supplier_price" class="form-label">Supplier Item Price</label>
                                                <input type="number" id="supplier_price" name="supplier_price[]" 
                                                    class="form-control" placeholder="Purchase Price">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4 mt-4 align-self-end">
                                <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add Product</button>
                                <a href="<?php echo e(route('product.index')); ?>" class="btn btn-secondary px-4">
                                    <i class="fa fa-times"></i> Cancel
                                </a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

     </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/multifield/jquery.multifield.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            var maxField = 10; //Input fields increment limitation
            var addButton = $('.add_button'); //Add button selector
            var wrapper = $('.field_wrapper'); //Input field wrapper
            var fieldHTML = '<div><select name="supplier_id[]" class="form-control"><option class="form-control">Select Supplier</option><?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><input name="supplier_price[]" class="form-control" type="text" placeholder="Enter Sales Price"><a href="javascript:void(0);" class="remove_button btn btn-danger" title="Delete field"><i class="fa fa-minus"></i></a></div>'
            var x = 1; //Initial field counter is 1

            //Once add button is clicked
            $(addButton).click(function(){
                //Check maximum number of input fields
                if(x < maxField){
                    x++; //Increment field counter
                    $(wrapper).append(fieldHTML); //Add field html
                }
            });

            //Once remove button is clicked
            $(wrapper).on('click', '.remove_button', function(e){
                e.preventDefault();
                $(this).parent('div').remove(); //Remove field html
                x--; //Decrement field counter
            });

            $('#example-2').multifield({
                section: '.group',
                btnAdd:'#btnAdd-2',
                btnRemove:'.btnRemove'
            });

            // Product suggestions (autocomplete)
             $("#product_name").on("keyup", function () {
                let query = $(this).val().trim();

                if (query.length > 1) {
                    $.ajax({
                        url: "<?php echo e(route('products.suggest')); ?>",
                        type: "GET",
                        data: { query: query },
                        dataType: "json",
                        success: function (data) {
                            let list = Array.isArray(data) ? data : data.items;
                            let suggestions = "";

                            if (list && list.length > 0) {
                                list.forEach(function (item) {
                                    suggestions += `
                                        <div class="list-group-item list-group-item-action product-suggestion"
                                            data-item='${JSON.stringify(item)}'
                                            style="cursor:pointer;">
                                            ${item.item_description}
                                        </div>`;
                                });
                                $("#productSuggestions").html(suggestions).show();
                            } else {
                                $("#productSuggestions").hide();
                            }
                        },
                        error: function (xhr) {
                            console.error("AJAX Error:", xhr.responseText);
                        }
                    });
                } else {
                    $("#productSuggestions").hide();
                }
            });

             $(document).on("click", ".product-suggestion", function (e) {
                e.preventDefault();
                e.stopPropagation();

                let item = $(this).data("item");

                $("#product_name").val(item.item_description);
                $("#supplier_product_code").val(item.item_code);
                $("#productSuggestions").fadeOut(150);

                // Fetch supplier info
                $.ajax({
                    url: "<?php echo e(route('products.suppliers')); ?>",
                    type: "GET",
                    data: { item_code: item.item_code },
                    success: function (data) {
                        if (Array.isArray(data) && data.length > 0) {
                            let supplier = data[0];
                            $("#supplier_id").val(supplier.id);
                            $("#supplier_name").val(supplier.name);
                            $("#supplier_price").val(supplier.item_price);

                            console.log("supplier name",supplier.name);
                            // Change PL → AV in product name only if supplier is 1st Tool Trading Inc
                            if (supplier.name.trim().toLowerCase().includes("1st tool")) {
                                let currentProductText = $("#product_name").val();
                                let updatedProductText = currentProductText.replace(/^PL/i, "AV");
                                console.log("updated product name",updatedProductText)
                                $("#product_name").val(updatedProductText);
                            }
                        } else {
                            alert("No suppliers found for this product");
                        }
                    },
                    error: function (xhr) {
                        console.error("Supplier AJAX Error:", xhr.responseText);
                    }
                });
            });
            $(document).on("click", function (e) {
                if (!$(e.target).closest("#product_name, #productSuggestions").length) {
                    $("#productSuggestions").fadeOut(150);
                }
            });
        });
        // function generateProductCode() {
        //     const prefix = "AVT";
        //     const timestamp = Date.now().toString().slice(-6); // last 6 digits of timestamp
        //     const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        //     return prefix + timestamp + random;
        // }

        // Set it when the page loads
        $('#product_code').val(generateProductCode());

         // Initial stock & remaining stock inputs
        const initialStockInput = $('input[name="quantity"]');
        const remainingStockInput = $('input[name="remaining_stock"]');

        // Auto-update remaining stock when initial changes
        initialStockInput.on('input', function() {
            remainingStockInput.val($(this).val());
            updateAllNewQty();
        });

        // Auto-update New Initial Qty when adjustment changes
        $('#adjustmentTable').on('input', '.adjustment', function() {
            updateRowNewQty($(this).closest('tr'));
        });

        function updateRowNewQty(row) {
            const initialQty = parseFloat(initialStockInput.val()) || 0;
            const remainingStock = parseFloat(remainingStockInput.val()) || 0;
            const adjustment = parseFloat(row.find('.adjustment').val()) || 0;

            const newInitialQty = remainingStock + adjustment;
            row.find('.new-initial-qty').val(newInitialQty);
        }

        function updateAllNewQty() {
            $('#adjustmentTable tbody tr').each(function() {
                updateRowNewQty($(this));
            });
        }

        // Initialize table values
        updateAllNewQty();
        
    </script>

<?php $__env->stopPush(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/product/create.blade.php ENDPATH**/ ?>