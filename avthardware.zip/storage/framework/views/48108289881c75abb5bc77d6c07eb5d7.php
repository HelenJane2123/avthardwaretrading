

<?php $__env->startSection('title', 'Customer | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="app-content">
        <div class="app-title d-flex justify-content-between align-items-center">
            <div>
                <h1><i class="fa fa-users"></i> Manage Customers</h1>
                <p class="text-muted mb-0">View, add, edit, and manage all customers</p>
            </div>
            <ul class="app-breadcrumb breadcrumb side">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item">Customer</li>
                <li class="breadcrumb-item active">Manage</li>
            </ul>
        </div>

        <div class="d-flex justify-content-between mb-3">
            <a class="btn btn-primary shadow-sm" href="<?php echo e(route('customer.create')); ?>">
                <i class="fa fa-plus"></i> Add Customer
            </a>
            <a class="btn btn-success shadow-sm" href="<?php echo e(route('export.customers')); ?>">
                <i class="fa fa-file-excel-o"></i> Export to Excel
            </a>
        </div>

          <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="tile shadow-sm rounded">
            <h3 class="tile-title mb-3"><i class="fa fa-table"></i> Customer Records</h3>
            <div class="tile-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered text-center align-middle" id="sampleTable">
                        <thead class="thead-dark">
                            <tr>
                                <th>Customer Code</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Tax No.</th>
                                <th>Details</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge badge-info"><?php echo e($customer->customer_code); ?></span></td>
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e($customer->address); ?></td>
                                <td><?php echo e($customer->mobile); ?></td>
                                <td><?php echo e($customer->email); ?></td>
                                <td><?php echo e($customer->tax); ?></td>
                                <td><?php echo e($customer->details); ?></td>
                                <td>
                                    <span class="badge <?php echo e($customer->status == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo e($customer->status == 1 ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($customer->created_at)->format('M d, Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($customer->updated_at)->format('M d, Y')); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a class="btn btn-sm btn-primary" 
                                           href="<?php echo e(route('customer.edit', $customer->id)); ?>" 
                                           title="Edit">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <button class="btn btn-sm btn-danger" 
                                                type="button" 
                                                onclick="deleteTag(<?php echo e($customer->id); ?>)"
                                                title="Delete">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </div>
                                    <form id="delete-form-<?php echo e($customer->id); ?>" 
                                          action="<?php echo e(route('customer.destroy',$customer->id)); ?>" 
                                          method="POST" 
                                          class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('/')); ?>js/plugins/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/plugins/dataTables.bootstrap.min.js"></script>
    <script>
        $('#sampleTable').DataTable({
            "order": [[ 0, "desc" ]],
            "pageLength": 10,
            "responsive": true
        });
    </script>
    <script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
    <script>
        function deleteTag(id) {
            swal({
                title: 'Are you sure?',
                text: "This action cannot be undone!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<i class="fa fa-check"></i> Yes, delete it!',
                cancelButtonText: '<i class="fa fa-times"></i> Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-' + id).submit();
                } else if (result.dismiss === swal.DismissReason.cancel) {
                    swal('Cancelled', 'Your data is safe :)', 'error')
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/customer/index.blade.php ENDPATH**/ ?>