

<?php $__env->startSection('title', 'Estimated Income | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="app-content">
        <div class="app-title d-flex justify-content-between align-items-center">
            <div>
                <h1><i class="fa fa-line-chart"></i> Estimated Income Report</h1>
                <p class="text-muted mb-0">
                    View sales and purchase comparison by date range, customer, and product. 
                    Analyze estimated profit (Sales Price − Purchase Price) × Quantity Sold to monitor income trends weekly, monthly, or quarterly.
                </p>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-12">
                <div class="tile shadow-sm">
                    <h3 class="tile-title mb-3"><i class="fa fa-bar-chart"></i> Estimated Income Report</h3>
                    <div class="tile-body">
                        <div class="container">
                            
                            <form method="GET" action="<?php echo e(route('reports.estimated_income_report')); ?>">
                                <div class="row align-items-end g-2">
                                    <!-- Filter Type -->
                                    <div class="col-md-2">
                                        <label class="form-label">Filter Type</label>
                                        <select name="filter_type" class="form-control">
                                            <option value="weekly" <?php echo e(request('filter_type')=='weekly'?'selected':''); ?>>Weekly</option>
                                            <option value="monthly" <?php echo e(request('filter_type')=='monthly'?'selected':''); ?>>Monthly</option>
                                            <option value="quarterly" <?php echo e(request('filter_type')=='quarterly'?'selected':''); ?>>Quarterly</option>
                                            <option value="custom" <?php echo e(request('filter_type')=='custom'?'selected':''); ?>>Custom</option>
                                        </select>
                                    </div>

                                    <!-- Start Date -->
                                    <div class="col-md-2">
                                        <label class="form-label">Start Date</label>
                                        <input type="date" name="start_date" class="form-control"
                                            value="<?php echo e(request('start_date', now()->startOfMonth()->toDateString())); ?>">
                                    </div>

                                    <!-- End Date -->
                                    <div class="col-md-2">
                                        <label class="form-label">End Date</label>
                                        <input type="date" name="end_date" class="form-control"
                                            value="<?php echo e(request('end_date', now()->toDateString())); ?>">
                                    </div>

                                    <!-- Customer -->
                                    <div class="col-md-3">
                                        <label class="form-label">Customer</label>
                                        <select name="customer_id" class="form-control">
                                            <option value="">-- All Customers --</option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($customer->id); ?>"
                                                    <?php echo e(request('customer_id') == $customer->id ? 'selected' : ''); ?>>
                                                    <?php echo e($customer->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- Product -->
                                    <div class="col-md-3">
                                        <label class="form-label">Product</label>
                                        <select name="product_id" class="form-control">
                                            <option value="">-- All Products --</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>"
                                                    <?php echo e(request('product_id') == $product->id ? 'selected' : ''); ?>>
                                                    <?php echo e($product->product_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- Buttons -->
                                    <div class="col-md-12 d-flex justify-content-end gap-2 mt-3">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-filter"></i> Filter</button>
                                        <a href="<?php echo e(route('reports.estimated_income_export', request()->all())); ?>" class="btn btn-success">
                                            <i class="fa fa-file-excel-o"></i> Export
                                        </a>
                                    </div>
                                </div>
                            </form>

                            
                            <div class="table-responsive mt-4">
                                <table class="table table-striped table-hover table-bordered" id="EstimatedIncomeTable">
                                    <thead class="table-dark text-center align-middle">
                                       <tr>
                                            <th>Invoice #</th>
                                            <th>Purchase #</th>
                                            <th>Date</th>
                                            <th>Customer</th>
                                            <th>Product</th>
                                            <th>Supplier</th> 
                                            <th>Qty Sold</th>
                                            <th>Qty Purchased</th>
                                            <th>Sales Price</th>
                                            <th>Purchase Price</th>
                                            <th>Total Sales</th>
                                            <th>Estimated Income</th>
                                            <th>Profit %</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($row->invoice_number); ?></td>
                                                <td><?php echo e($row->purchase_number ?? 'N/A'); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($row->invoice_date)->format('Y-m-d')); ?></td>
                                                <td><?php echo e($row->customer_name); ?></td>
                                                <td><?php echo e($row->product_name); ?></td>
                                                <td><?php echo e($row->supplier_name ?? 'N/A'); ?></td> 
                                                <td class="text-end"><?php echo e(number_format($row->quantity_sold, 0)); ?></td>
                                                <td class="text-end"><?php echo e(number_format($row->quantity_purchased, 0)); ?></td>
                                                <td class="text-end"><?php echo e(number_format($row->sales_price, 2)); ?></td>
                                                <td class="text-end"><?php echo e(number_format($row->purchase_price, 2)); ?></td>
                                                <td class="text-end"><?php echo e(number_format($row->total_sales, 2)); ?></td>
                                                <td class="text-end fw-bold text-success"><?php echo e(number_format($row->estimated_income, 2)); ?></td>
                                                <td class="text-end"><?php echo e(number_format($row->profit_percentage ?? 0, 2)); ?>%</td> 
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="13" class="text-center">No records found for selected filters.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                   <?php if(isset($summary)): ?>
                                    <tfoot class="table-secondary fw-bold">
                                        <tr>
                                            <td colspan="10" class="text-end">Grand Total:</td>
                                            <td class="text-end"><?php echo e(number_format($summary->total_sales ?? 0, 2)); ?></td>
                                            <td class="text-end text-success"><?php echo e(number_format($summary->total_income ?? 0, 2)); ?></td>
                                            <td class="text-end"><?php echo e(number_format($summary->average_profit ?? 0, 2)); ?>%</td> 
                                        </tr>
                                    </tfoot>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $('#EstimatedIncomeTable').DataTable({
        "pageLength": 25,
        "order": [[2, 'desc']],
        "responsive": true
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/reports/estimated_income_report.blade.php ENDPATH**/ ?>