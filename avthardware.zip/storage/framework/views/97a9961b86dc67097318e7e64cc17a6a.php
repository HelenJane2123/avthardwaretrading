<div class="row">
    <!-- Left Side: Product Image -->
    <div class="col-md-4 text-center">
        <?php if($product->image): ?>
            <img src="<?php echo e(asset('images/product/' . $product->image)); ?>" 
                 alt="<?php echo e($product->product_name); ?>" 
                 class="img-fluid rounded shadow-sm mb-3" 
                 style="max-height: 250px;">
        <?php else: ?>
            <img src="<?php echo e(asset('images/no-image.png')); ?>" 
                 alt="No image available" 
                 class="img-fluid rounded shadow-sm mb-3" 
                 style="max-height: 250px;">
        <?php endif; ?>
    </div>

    <!-- Right Side: Product Details -->
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Product Code:</strong> <?php echo e($product->product_code); ?></p>
                <p><strong>Supplier Item Code:</strong> <?php echo e($product->supplier_product_code); ?></p>
                <p><strong>Product:</strong> <?php echo e($product->product_name); ?></p>
                <p><strong>Description:</strong> <?php echo e($product->description); ?></p>
                <p><strong>Model:</strong> <?php echo e($product->model ?? 'N/A'); ?></p>
                <p><strong>Serial:</strong> <?php echo e($product->serial_number ?? 'N/A'); ?></p>
                <p><strong>Discount:</strong> <?php echo e($product->tax->name ?? 'No Discount'); ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Category:</strong> <?php echo e($product->category->name); ?></p>
                <p><strong>Unit:</strong> <?php echo e($product->unit->name); ?></p>
                <p><strong>Quantity:</strong> <?php echo e($product->quantity); ?></p>
                <p><strong>Quantity on Hand:</strong> <?php echo e($product->remaining_stock); ?></p>
                <p><strong>Sales Price:</strong> <?php echo e($product->sales_price); ?></p>
                <p><strong>Threshold:</strong> <?php echo e($product->threshold); ?></p>
                <p><strong>Status:</strong> <?php echo e($product->status); ?></p>
                <p><strong>Volume Less:</strong> <?php echo e($product->volume_less ?? 'N/A'); ?></p>
                <p><strong>Regular Less:</strong> <?php echo e($product->regular_less ?? 'N/A'); ?></p>
            </div>
        </div>
    </div>
</div>

<hr>

<!-- Suppliers Section -->
<h5>Suppliers</h5>
<ul>
    <?php $__currentLoopData = $product->suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($supplier->name); ?> - Supplier Price: <?php echo e($supplier->pivot->price); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/product/partials/view.blade.php ENDPATH**/ ?>