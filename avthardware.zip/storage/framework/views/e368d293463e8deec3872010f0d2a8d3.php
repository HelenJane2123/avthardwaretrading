

<?php $__env->startSection('titel', 'Invoice | '); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-th-list"></i> Invoices Table</h1>
                <p class="text-muted mb-0">View, update, or delete existing invoices.</p>
            </div>
            <ul class="app-breadcrumb breadcrumb side">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item">Invoice</li>
                <li class="breadcrumb-item active"><a href="#">Invoice Table</a></li>
            </ul>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <a class="btn btn-primary" href="<?php echo e(route('invoice.create')); ?>"><i class="fa fa-plus"></i> Create New Invoice</a>
            <a class="btn btn-success shadow-sm" href="<?php echo e(route('export.invoices')); ?>">
                <i class="fa fa-file-excel-o"></i> Export to Excel
            </a>
        </div>

        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa fa-check-circle"></i> <?php echo e(session()->get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="row mt-2">
            <div class="col-md-12">
                <div class="tile">
                <h3 class="tile-title mb-3"><i class="fa fa-table"></i> Invoice Records</h3>
                    <div class="tile-body">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Customer</th>
                                    <th>Invoice Date</th>
                                    <th>Due Date</th>
                                    <th>Subtotal</th>
                                    <th>Discount Type</th>
                                    <th>Grand Total</th>
                                    <th>Outstanding Balance</th>
                                    <th>Status</th>
                                    <th>Payment Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="badge badge-info"><?php echo e($invoice->invoice_number); ?></span></td>
                                        <td><?php echo e($invoice->customer->name); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($invoice->invoice_date)->format('M d, Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($invoice->due_date)->format('M d, Y')); ?></td>
                                        <td><?php echo e(number_format($invoice->subtotal, 2)); ?></td>
                                        <td>
                                           <?php if($invoice->discount_type == 'per_item'): ?>
                                                <span class="badge badge-success">Per Item</span>
                                            <?php elseif($invoice->discount_value > 0): ?>
                                                <span class="badge badge-primary">
                                                    Overall - <?php echo e($invoice->discount_value); ?> <?php echo e($invoice->discount_type == 'overall' ? '%' : '₱'); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">
                                                   No Discount
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(number_format($invoice->grand_total, 2)); ?></td>
                                        <td><?php echo e(number_format($invoice->outstanding_balance, 2)); ?></td>
                                        <td>
                                            <span class="badge 
                                                <?php if($invoice->invoice_status == 'approved'): ?> bg-success
                                                <?php elseif($invoice->invoice_status == 'pending'): ?> bg-warning
                                                <?php elseif($invoice->invoice_status == 'canceled'): ?> bg-danger
                                                <?php endif; ?>">
                                                <?php echo e(ucfirst($invoice->invoice_status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge 
                                                <?php if($invoice->payment_status == 'paid'): ?> bg-success
                                                <?php elseif($invoice->payment_status == 'pending'): ?> bg-warning
                                                <?php elseif($invoice->payment_status == 'overdue'): ?> bg-danger
                                                <?php elseif($invoice->payment_status == 'partial'): ?> bg-info
                                                <?php endif; ?>">
                                                <?php echo e(ucfirst($invoice->payment_status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-primary btn-sm view-invoice" data-id="<?php echo e($invoice->id); ?>">
                                                <i class="fa fa-eye"></i>
                                            </button>

                                           <?php if($invoice->invoice_status == 'approved'): ?>
                                                
                                                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('invoice.print', $invoice->id)); ?>" target="_blank">
                                                    <i class="fa fa-print"></i>
                                                </a>

                                            <?php elseif($invoice->invoice_status == 'canceled'): ?>
                                                <span class="badge bg-danger text-light">
                                                    This invoice is already canceled
                                                </span>
                                            <?php else: ?>
                                                
                                                <a class="btn btn-info btn-sm" href="<?php echo e(route('invoice.edit', $invoice->id)); ?>">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <?php if(auth()->user()->user_role === 'super_admin'): ?>
                                                    <button class="btn btn-success btn-sm" onclick="approveInvoice(<?php echo e($invoice->id); ?>)">
                                                        <i class="fa fa-check"></i> Approve
                                                    </button>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <button class="btn btn-danger btn-sm" onclick="deleteTag(<?php echo e($invoice->id); ?>)">
                                                <i class="fa fa-trash"></i>
                                            </button>

                                            <form id="delete-form-<?php echo e($invoice->id); ?>" 
                                                action="<?php echo e(route('invoice.destroy',$invoice->id)); ?>" 
                                                method="POST" style="display:none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Invoice Modal -->
    <div class="modal fade" id="invoiceModal" tabindex="-1" role="dialog" aria-labelledby="invoiceModalLabel" aria-modal="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="invoiceModalLabel">Invoice Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="invoiceDetails">
                    <!-- AJAX loads details here -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/')); ?>js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
    <script type="text/javascript">
        function deleteTag(id) {
            swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                }
            })
        }

       // Show modal with invoice details safely
        $(document).on('click', '.view-invoice', function () {
            const id = $(this).data('id');
            const $modal = $('#invoiceModal');
            const $details = $('#invoiceDetails');

            // First, clear old data
            $details.html('<p class="text-muted">Loading details...</p>');

             // Force remove if Bootstrap left it behind
            $modal.removeAttr('aria-hidden');

            // Show modal first (Bootstrap handles aria attributes properly)
            $modal.modal('show');

            // Then load the content dynamically
            $.get(`<?php echo e(url('invoice')); ?>/${id}`, function (data) {
                // Insert the new HTML *after* the modal is visible
                $details.html(data);
            });
        });

        // Optional: clean up when closed
        $('#invoiceModal').on('hidden.bs.modal', function () {
            $('#invoiceDetails').empty();
        });

        function approveInvoice(id) {
            swal({
                title: 'Confirm Approval',
                text: 'Only Admin can approve invoices.',
                input: 'password',
                inputPlaceholder: 'Enter Admin password',
                showCancelButton: true,
                confirmButtonText: 'Approve',
                confirmButtonColor: '#28a745',
                cancelButtonText: 'Cancel',
                preConfirm: function (password) {
                    return new Promise(function (resolve, reject) {
                        if (!password) {
                            reject('Please enter your password');
                            return;
                        }

                        $.ajax({
                            url: `/invoice/${id}/approve`,
                            type: 'PUT',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>',
                                password: password
                            },
                            success: function (response) {
                                console.log("test response",response);
                                if (response.error) {
                                    reject(response.error);
                                } else {
                                    resolve(response);
                                }
                            },
                            error: function () {
                                reject('An error occurred during approval.');
                            }
                        });
                    });
                }
            }).then(function (result) {
                if (result && result.value && result.value.success) {
                    swal({
                        type: 'success',
                        title: 'Invoice has been approved!',
                        text: result.value.success,
                        timer: 1500,
                        showConfirmButton: false
                    });
                    setTimeout(() => location.reload(), 1500);
                }
            }).catch(function (error) {
                swal.showInputError ? swal.showInputError(error) : swal('Error', error, 'error');
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/invoice/index.blade.php ENDPATH**/ ?>