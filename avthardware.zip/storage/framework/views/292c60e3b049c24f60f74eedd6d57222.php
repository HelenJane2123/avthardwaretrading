<!DOCTYPE html>
<html>
<head>
    <title>Purchase Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 13px;
            margin: 20px;
            color: #000;
        }
        .header {
            display: flex;
            justify-content: space-between;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .header-left {
            width: 60%;
        }
        .header-right {
            text-align: right;
            width: 40%;
        }
        h2 {
            margin: 0;
            color: #004080;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        th, td {
            border: 1px solid #000;
            padding: 6px;
            text-align: left;
        }
        th {
            background: #004080;
            color: #fff;
            font-size: 12px;
        }
        .no-border td {
            border: none;
            padding: 3px;
        }
        .totals {
            width: 100%;
            float: right;
        }
        .totals td {
            text-align: right;
        }
        .comments {
            border: 1px solid #000;
            padding: 10px;
            margin-top: 30px;
            height: 80px;
        }
        .footer {
            margin-top: 40px;
            font-size: 11px;
            text-align: center;
        }
        .print-btn {
            margin-bottom: 20px;
        }

        /* Hide print button when printing */
        @media print {
            .print-btn {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="print-btn">
    <button onclick="window.print()">Print Purchase Order</button>
</div>

<div class="header" style="border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px;">
    <div style="text-align: left;">
        <h2 style="margin:0; font-size:26px; text-decoration: underline;">
            PURCHASE ORDER
        </h2>
    </div>
    <div style="display: flex; align-items: center; position: relative;">
        <div style="display: flex; align-items: center;">
            <img src="<?php echo e(asset('images/avt_logo.png')); ?>" alt="Company Logo" style="height:60px; margin-right: 12px;">
            <div>
                <p style="margin:0; font-weight:bold;">AVT HARDWARE TRADING</p>
                <p style="margin:0; font-size:12px; line-height:1.4;">
                    Wholesale of hardware, electricals, & plumbing supply etc.<br>
                    Contact: 0936-8834-275 / 0999-3669-539                
                </p>
            </div>
        </div>
    </div>
</div>

<table width="100%" style="margin-bottom: 20px;">
    <tr>
        <td>
            <strong>Vendor:</strong><br>
            <?php echo e($purchase->supplier->name); ?><br>
            <?php echo e($purchase->supplier->address); ?><br>
            <?php echo e($purchase->supplier->phone); ?>

        </td>
        <td>
            <strong>Ship To:</strong><br>
            AVT HARDWARE TRADING<br>
            0936-8834-275 / 0999-3669-539
        </td>
        <td>
            <strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($purchase->created_at)->format('m/d/Y')); ?><br>
            <strong>PO #:</strong> <?php echo e($purchase->po_number); ?>

        </td>
    </tr>
    <tr>
        <td colspan="3" style="padding-top: 10px;">
            <table width="100%" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse;">
                <tr>
                    <?php if($purchase->paymentMode && strtolower($purchase->paymentMode->name) === 'pdc/check'): ?>
                        <td>
                            <strong>Payment Terms:</strong> <?php echo e($purchase->paymentMode->term ?? 'N/A'); ?> days
                        </td>
                    <?php else: ?>
                        <td>
                            <strong>Payment Terms:</strong> -
                        </td>
                    <?php endif; ?>

                    <td>
                        <strong>Payment Method:</strong> <?php echo e($purchase->paymentMode->name ?? '-'); ?>

                    </td>

                    <td colspan="2">
                        <strong>Salesman:</strong> <?php echo e($purchase->salesman['salesman_name'] ?? '-'); ?>

                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<table>
    <thead>
        <tr>
            <th style="width: 15%;">ITEM #</th>
            <th style="width: 45%;">DESCRIPTION</th>
            <th style="width: 10%;">QTY</th>
            <th style="width: 15%;">UNIT PRICE</th>
            <th style="width: 15%;">TOTAL</th>
        </tr>
    </thead>
    <tbody>
        <?php $subtotal = 0; ?>
        <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product_code ?? '-'); ?></td>
                <td>
                    <?php echo e($item->supplierItem->item_description ?? 'N/A'); ?>

                    <?php if(!empty($item->discount) && $item->discount > 0): ?>
                        <br><small><strong>Discount:</strong> <?php echo e(number_format($item->discount, 2)); ?>%</small>
                    <?php endif; ?>
                </td>
                <td><?php echo e($item->qty); ?></td>
                <td><?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td><?php echo e(number_format($item->total, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table width="100%" style="margin-top: 30px;">
    <tr>
        <td width="60%" valign="top" style="padding-right: 20px; border: none !important;">
            <strong>Comments or Special Instructions:</strong><br>
            <div style="border: 1px solid #000; min-height: 80px; padding: 10px;">
                <?php echo e($purchase->remarks ?? ''); ?>

            </div>
        </td>
        <td width="40%" valign="top" style="border: none !important;">
            <table class="totals">
                <tr>
                    <td><strong>SUBTOTAL</strong></td>
                    <td><?php echo e(number_format($purchase->subtotal, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>DISCOUNT</strong></td>
                    <td><?php echo e($purchase->discount_value); ?></td>
                </tr>
                <tr>
                    <td><strong>SHIPPING</strong></td>
                    <td><?php echo e(number_format($purchase->shipping, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>OTHER</strong></td>
                    <td><?php echo e(number_format($purchase->other_charges, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>TOTAL</strong></td>
                    <td><strong><?php echo e(number_format($purchase->grand_total, 2)); ?></strong></td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<table width="100%" style="margin-top: 20px; border: 1px solid #000; border-collapse: collapse;">
    <tr style="background-color: #004080; color: #fff;">
        <th colspan="4" style="padding: 8px; text-align: left;">PAYMENT SUMMARY</th>
    </tr>
    <tr>
        <td><strong>Total Amount:</strong></td>
        <td>₱<?php echo e(number_format($purchase->grand_total, 2)); ?></td>
        <td><strong>Total Paid:</strong></td>
        <td>₱<?php echo e(number_format($totalPaid, 2)); ?></td>
    </tr>
    <tr>
        <td><strong>Outstanding Balance:</strong></td>
        <td>₱<?php echo e(number_format($outstanding, 2)); ?></td>
        <td><strong>Status:</strong></td>
        <td style="font-weight:bold; color:
            <?php echo e($paymentStatus === 'Fully Paid' ? 'green' : ($paymentStatus === 'Partial Payment' ? 'orange' : 'red')); ?>">
            <?php echo e($paymentStatus); ?>

        </td>
    </tr>
</table>


<?php if($purchase->payments->count() > 0): ?>
    <table width="100%" style="margin-top: 15px; border: 1px solid #000; border-collapse: collapse;">
        <tr style="background-color: #004080; color: #fff;">
            <th colspan="4" style="padding: 8px; text-align: left;">PAYMENT HISTORY</th>
        </tr>
        <tr>
            <th style="width: 20%;">Date</th>
            <th style="width: 30%;">Amount Paid</th>
            <th style="width: 25%;">Outstanding Balance</th>
            <th style="width: 25%;">Payment Status</th>
        </tr>
        <?php $__currentLoopData = $purchase->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('m/d/Y')); ?></td>
                <td>₱<?php echo e(number_format($payment->amount_paid, 2)); ?></td>
                <td>₱<?php echo e(number_format($payment->outstanding_balance, 2)); ?></td>
                <td><?php echo e(ucfirst($payment->payment_status)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <p style="margin-top: 15px; font-style: italic;">No payments recorded yet.</p>
<?php endif; ?>

<!-- <div style="clear: both;"></div>
<div class="footer">
    If you have any questions about this purchase order, please contact<br>
    [Name, Phone #, E-mail]
</div> -->

</body>
</html>
<?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/purchase/partial/print.blade.php ENDPATH**/ ?>