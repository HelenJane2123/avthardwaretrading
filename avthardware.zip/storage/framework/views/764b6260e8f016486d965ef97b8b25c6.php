<h5>Invoice Details</h5>
<table class="table table-sm table-bordered">
    <tr>
        <th>Invoice #</th>
        <td><?php echo e($collection->invoice->invoice_number); ?></td>
    </tr>
    <tr>
        <th>Invoice Date</th>
        <td><?php echo e(\Carbon\Carbon::parse($collection->invoice->invoice_date)->format('M d, Y')); ?></td>
    </tr>
    <tr>
        <th>Due Date</th>
        <td><?php echo e(\Carbon\Carbon::parse($collection->invoice->due_date)->format('M d, Y')); ?></td>
    </tr>
    <tr>
        <th>Invoice Amount</th>
        <td><?php echo e(number_format($collection->invoice->grand_total, 2)); ?></td>
    </tr>
</table>

<h5>Customer Details</h5>
<table class="table table-sm table-bordered">
    <tr>
        <th>Name</th>
        <td><?php echo e($collection->invoice->customer->name); ?></td>
    </tr>
    <tr>
        <th>Email</th>
        <td><?php echo e($collection->invoice->customer->email ?? '-'); ?></td>
    </tr>
    <tr>
        <th>Phone</th>
        <td><?php echo e($collection->invoice->customer->mobile ?? '-'); ?></td>
    </tr>
</table>

<h5>Collection Details</h5>
<table class="table table-sm table-bordered">
    <tr>
        <th>Payment Date</th>
        <td><?php echo e(\Carbon\Carbon::parse($collection->payment_date)->format('M d, Y')); ?></td>
    </tr>
    <tr>
        <th>Amount Paid</th>
        <td><?php echo e(number_format($collection->amount_paid, 2)); ?></td>
    </tr>

    
    <?php if($collection->invoice->outstanding_balance > 0): ?>
        <tr>
            <th>Outstanding Balance</th>
            <td><?php echo e(number_format($collection->invoice->outstanding_balance, 2)); ?></td>
        </tr>
    <?php endif; ?>

    <tr>
        <th>Payment Status</th>
        <td><?php echo e(ucfirst($collection->invoice->payment_status)); ?></td>
    </tr>
    <tr>
        <th>Payment Method</th>
        <td><?php echo e($collection->invoice->paymentMode->name ?? '-'); ?></td>
    </tr>
</table>
<?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/collection/partials/details.blade.php ENDPATH**/ ?>