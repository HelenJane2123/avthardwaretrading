

<?php $__env->startSection('title', 'Purchase | '); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-edit"></i> Edit Purchase</h1>
            <p class="text-muted mb-0">Update supplier details or modify items in the purchase order.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Purchase</li>
            <li class="breadcrumb-item"><a href="#">Edit Purchase</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h3 class="tile-title">Edit Purchase Order</h3>
                <div class="tile-body">
                    <form method="POST" action="<?php echo e(route('purchase.update', $purchase->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row mb-4">
                            
                            <div class="col-md-4 form-group">
                                <label>Supplier</label>
                                <select name="supplier_id" id="supplierSelect" class="form-control" required>
                                    <option value="">Select Supplier</option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($supplier->id); ?>" 
                                            <?php echo e($supplier->id == $purchase->supplier_id ? 'selected' : ''); ?>>
                                            <?php echo e($supplier->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="col-md-3 form-group">
                                <label>Purchase Date</label>
                                <input type="date" name="date" class="form-control" 
                                    value="<?php echo e(old('date', $purchase->date)); ?>" required>
                            </div>

                            
                            <div class="col-md-3 form-group">
                                <label for="po_number">PO Number</label>
                                <input type="text" name="po_number" id="po_number" 
                                    class="form-control" value="<?php echo e($purchase->po_number); ?>" readonly>
                            </div>
                            
                            <div class="col-md-4 form-group">
                                <label for="salesman">Salesman</label>
                                <select name="salesman_id" id="salesman_id" class="form-control" required>
                                    <option value="">-- Select Salesman --</option>
                                    <?php $__currentLoopData = $salesman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesmen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($salesmen->id); ?>" 
                                            <?php echo e($salesmen->id == $purchase->salesman_id ? 'selected' : ''); ?>>
                                            <?php echo e($salesmen->salesman_name); ?> 
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="payment_id">Mode of Payment</label>
                                <select name="payment_id" id="payment_id" class="form-control" required>
                                    <option value="">-- Select Payment Mode --</option>
                                    <?php $__currentLoopData = $paymentModes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($mode->id); ?>" 
                                            <?php echo e($mode->id == $purchase->payment_id ? 'selected' : ''); ?>>
                                            <?php echo e($mode->name); ?> 
                                            <?php if($mode->term): ?> (<?php echo e($mode->term); ?> days) <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        
                        <div id="supplier-info" class="tile mt-3">
                            <h4 class="tile-title"><i class="fa fa-building"></i> Supplier Information</h4>
                            <div class="tile-body table-responsive">
                                <table class="table table-bordered table-striped">
                                    <tbody>
                                        <tr><th>Supplier Code</th><td><?php echo e($purchase->supplier->supplier_code); ?></td></tr>
                                        <tr><th>Name</th><td><?php echo e($purchase->supplier->name); ?></td></tr>
                                        <tr><th>Phone</th><td><?php echo e($purchase->supplier->mobile); ?></td></tr>
                                        <tr><th>Email</th><td><?php echo e($purchase->supplier->email); ?></td></tr>
                                        <tr><th>Address</th><td><?php echo e($purchase->supplier->address); ?></td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        
                        <div class="tile mt-4">
                            <h4 class="tile-title"><i class="fa fa-list"></i> Purchased Items</h4>
                            <table class="table table-bordered table-striped">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Product Code</th>
                                        <th>Product</th>
                                        <th>Unit</th>
                                        <th>Quantity Ordered</th>
                                        <th>Unit Price</th>
                                        <th>Discount (%)</th>
                                        <th>Amount</th>
                                        <th><a class="btn btn-success btn-sm addRow"><i class="fa fa-plus"></i></a></th>
                                    </tr>
                                </thead>
                                <tbody id="po-body">
                                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="text" name="product_code[]" class="form-control code" 
                                                value="<?php echo e($item->supplierItem->item_code); ?>" readonly>
                                        </td>
                                        <td>
                                            <select name="product_id[]" class="form-control productname">
                                                <option value="">Select Product</option>
                                                <?php $__currentLoopData = $supplierItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($supplierItem->id); ?>"
                                                            data-code="<?php echo e($supplierItem->item_code); ?>"
                                                            data-price="<?php echo e($supplierItem->item_price); ?>"
                                                            data-name="<?php echo e($supplierItem->item_description); ?>"
                                                            <?php echo e($supplierItem->id == $item->supplier_item_id ? 'selected' : ''); ?>>
                                                        <?php echo e($supplierItem->item_description); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <small class="text-muted d-block product-display mt-1"></small>
                                        </td>
                                        <td>
                                            <select name="unit[]" class="form-control unit">
                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unit->id); ?>" 
                                                        <?php echo e($unit->id == $item->unit ? 'selected' : ''); ?>>
                                                        <?php echo e($unit->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td><input type="number" name="qty[]" class="form-control qty" value="<?php echo e($item->qty); ?>"></td>
                                        <td><input type="text" name="price[]" class="form-control price" value="<?php echo e($item->unit_price); ?>"></td>
                                        <td><input type="text" name="dis[]" class="form-control dis" value="<?php echo e($item->discount); ?>"></td>
                                        <td><input type="text" name="amount[]" class="form-control amount" value="<?php echo e($item->amount); ?>" readonly></td>
                                        <td><a class="btn btn-danger btn-sm remove"><i class="fa fa-remove"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot class="bg-light">
                                    
                                    <tr>
                                        <th colspan="5" class="text-end">Discount Type</th>
                                        <th colspan="2">
                                            <select id="discount_type" name="discount_type" class="form-control">
                                                <option value="all" <?php echo e($purchase->discount_type == 'all' ? 'selected' : ''); ?>>All</option>
                                                <option value="overall" <?php echo e($purchase->discount_type == 'overall' ? 'selected' : ''); ?>>Overall</option>
                                                <option value="per_item" <?php echo e($purchase->discount_type == 'per_item' ? 'selected' : ''); ?>>Per Item</option>
                                            </select>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="5" class="text-end">Tax/Discount</th>
                                        <td colspan="2"><input type="text" class="form-control" name="discount_value" id="discount" value="<?php echo e($purchase->discount_value); ?>"></td>
                                    </tr>
                                    <tr>
                                        <th colspan="5" class="text-end">Shipping</th>
                                        <td colspan="2"><input type="number" class="form-control" name="shipping" id="shipping" value="<?php echo e($purchase->shipping); ?>"></td>
                                    </tr>
                                    <tr>
                                        <th colspan="5" class="text-end">Other Charges</th>
                                        <td colspan="2"><input type="number" class="form-control" name="other_charges" id="other" value="<?php echo e($purchase->other_charges); ?>"></td>
                                    </tr>
                                    <tr class="fw-bold">
                                        <th colspan="5" class="text-end">Subtotal</th>
                                        <td colspan="2"><input type="text" class="form-control" name="subtotal" id="subtotal" value="<?php echo e($purchase->subtotal); ?>" readonly></td>
                                    </tr>
                                    <tr class="fw-bold bg-secondary text-white">
                                        <th colspan="5" class="text-end">Grand Total</th>
                                        <td colspan="2"><input type="text" class="form-control" name="grand_total" id="grand_total" value="<?php echo e($purchase->grand_total); ?>" readonly></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                        <div class="form-group mb-4">
                            <label class="form-label">Comments / Special Instructions</label>
                            <textarea name="remarks" rows="3" class="form-control"><?php echo e($purchase->remarks); ?></textarea>
                        </div>
                        <div class="form-group mt-3">
                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-save"></i> Update Purchase Order
                            </button>
                            <a href="<?php echo e(route('purchase.index')); ?>" class="btn btn-secondary">
                                <i class="fa fa-arrow-left"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<script src="<?php echo e(asset('/')); ?>js/multifield/jquery.multifield.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){

    let supplierItems = <?php echo json_encode($supplierItems, 15, 512) ?>;

    // Add Row
    $('.addRow').on('click', function() {
        if (!supplierItems || supplierItems.length === 0) {
            alert('Please select a supplier first.');
            return;
        }
        addRow(supplierItems);
        calculateTotals();
    });

    function addRow(supplierItems = []) {
        let options = '<option value="">Select Product</option>';
        supplierItems.forEach(function(item) {
            options += `<option value="${item.id}" 
                                data-code="${item.item_code}" 
                                data-price="${item.item_price}" 
                                data-name="${item.item_description}">
                            ${item.item_description}
                        </option>`;
        });

        const newRow = `<tr>
            <td><input type="text" name="product_code[]" class="form-control code" readonly></td>
            <td>
                <select name="product_id[]" class="form-control productname">${options}</select>
                <small class="text-muted d-block product-display mt-1"></small>
            </td>
            <td>
                <select name="unit[]" class="form-control unit">
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td><input type="number" name="qty[]" class="form-control qty"></td>
            <td><input type="text" name="price[]" class="form-control price"></td>
            <td><input type="text" name="dis[]" class="form-control dis"></td>
            <td><input type="text" name="amount[]" class="form-control amount" readonly></td>
            <td><a class="btn btn-danger remove"><i class="fa fa-remove"></i></a></td>
        </tr>`;

        $('#po-body').append(newRow);
    }

    // Remove row
    $(document).on('click', '.remove', function () {
        var l = $('tbody tr').length;
        if(l==1){
            alert('You can\'t delete the last row');
            calculateTotals();
        } else {
            $(this).closest('tr').remove();
            calculateTotals();
        }
    });

    // Product change
    function updateDiscountFieldState() {
        const type = $('#discount_type').val();

        if (type === 'all') {
            // Enable both
            $('.dis').prop('disabled', false);
            $('#discount').prop('disabled', false);
        }
        else if (type === 'overall') {
            // Enable only overall discount
            $('.dis').prop('disabled', true);
            $('#discount').prop('disabled', false);
        } 
        else if (type === 'per_item') {
            // Enable only per-item discounts
            $('.dis').prop('disabled', false);
            $('#discount').prop('disabled', true).val('');
        } 
        calculateTotals();
    }

    // When user changes discount type
    $(document).on('change', '#discount_type', function() {
        updateDiscountFieldState();
    });

    function updateProductDisplay($select) {
        const selected = $select.find(':selected');
        const $row = $select.closest('tr');
        const name = selected.data('name') || '';
        const code = selected.data('code') || '';
        const price = selected.data('price') || '';

        $row.find('.product-display').text(name);
        $row.find('.code').val(code);
        $row.find('.price').val(price);

        calculateTotals();
    }

    $(document).on('change', '.productname', function() {
        updateProductDisplay($(this));
    });

    // Recalculate totals when any field changes
    $(document).on('input', '.qty, .price, .dis, #discount, #shipping, #other', function() {
        calculateTotals();
    });

    // Calculate Totals
    function calculateTotals() {
        let subtotal = 0;
        let perItemDiscountTotal = 0;

        const discountType = $('#discount_type').val();

        // 1️⃣ Calculate per-item totals if enabled (either "per_item" or "all")
        $('#po-body tr').each(function () {
            const qty   = parseFloat($(this).find('.qty').val())   || 0;
            const price = parseFloat($(this).find('.price').val()) || 0;
            const disP  = parseFloat($(this).find('.dis').val())   || 0;

            const lineBase = qty * price;
            let lineDisc = 0;

            if (discountType === 'per_item' || discountType === 'all') {
                lineDisc = (disP > 0) ? (lineBase * disP / 100) : 0;
            }

            const lineNet = lineBase - lineDisc;
            subtotal += lineBase;
            perItemDiscountTotal += lineDisc;

            $(this).find('.amount').val(lineNet.toFixed(2));
        });

        // 2️⃣ Apply overall discount if enabled (either "overall" or "all")
        let overallDiscount = 0;
        if (discountType === 'overall' || discountType === 'all') {
            const overallPct = parseFloat($('#discount').val()) || 0;
            const baseForOverall = (discountType === 'all') 
                ? (subtotal - perItemDiscountTotal) 
                : subtotal;
            overallDiscount = baseForOverall * overallPct / 100;
        }

        // 3️⃣ Add shipping & other charges
        const shipping = parseFloat($('#shipping').val()) || 0;
        const other    = parseFloat($('#other').val())    || 0;

        // 4️⃣ Compute grand total
        const grandTotal = (subtotal - perItemDiscountTotal - overallDiscount) + shipping + other;

        // 5️⃣ Update fields
        $('#subtotal').val(subtotal.toFixed(2));
        $('#grand_total').val(grandTotal.toFixed(2));
    }

    calculateTotals();
    updateDiscountFieldState();

    $('.productname').each(function() {
        updateProductDisplay($(this));
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avthardwaretrading\resources\views/purchase/edit.blade.php ENDPATH**/ ?>