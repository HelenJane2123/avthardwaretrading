@extends('layouts.master')

@section('title', 'Edit Product | ')

@section('content')
@include('partials.header')
@include('partials.sidebar')

<main class="app-content">
    <div class="app-title d-flex justify-content-between align-items-center">
        <div>
            <h1><i class="fa fa-edit"></i> Edit Inventory</h1>
            <p class="text-muted mb-0">Update the details of an existing product in your inventory.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Products</li>
            <li class="breadcrumb-item active">Edit</li>
        </ul>
    </div>

    @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fa fa-check-circle"></i> {{ session()->get('message') }}
            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    @endif

    <div class="mb-3">
        <a class="btn btn-outline-primary" href="{{ route('product.index') }}">
            <i class="fa fa-list"></i> Manage Products
        </a>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="tile shadow-sm rounded">
                <h3 class="tile-title border-bottom pb-2">Edit Product Form</h3>
                <div class="tile-body">
                    <form action="{{ route('product.update', $product->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <!-- Basic Info -->
                        <div class="card mb-4 shadow-sm">
                            <div class="card-header bg-dark text-white">
                                <h5 class="mb-0">Basic Information</h5>
                            </div>
                            <div class="card-body row">
                                <!-- LEFT SIDE IMAGE -->
                                <div class="col-md-3 text-center">
                                    @if($product->image)
                                        <img src="{{ asset('/images/product/' . $product->image) }}"
                                             class="img-thumbnail mb-2" 
                                             style="max-width: 200px; max-height: 200px;">
                                    @else
                                        <i class="fa fa-image fa-5x text-muted mb-2"></i>
                                    @endif
                                    <input type="file" name="image" class="form-control mt-2">
                                </div>

                                <!-- RIGHT SIDE FIELDS -->
                                <div class="col-md-9">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <label class="fw-bold">Product Name</label>
                                            <input type="text" name="product_name" class="form-control" id="product_name" 
                                                value="{{ $product->product_name }}" required>
                                            <div id="productSuggestions" class="list-group position-absolute w-100 shadow" style="display:none; z-index:1000;"></div>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="fw-bold">Product Code</label>
                                            <input type="text" class="form-control" value="{{ $product->product_code }}" readonly>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="fw-bold">Supplier Product Code</label>
                                            <input type="text" class="form-control" name="supplier_product_code" 
                                                id="supplier_product_code" value="{{ $product->supplier_product_code }}" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                            <label class="control-label fw-bold">Product Description</label>
                                            <textarea name="description"
                                                class="form-control"
                                                rows="2">{{ $product->description }}</textarea>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label class="control-label fw-bold">Volume Less</label>
                                        <textarea name="volume_less"
                                            class="form-control"
                                            rows="2">{{ $product->volume_less }}</textarea>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label class="control-label fw-bold">Regular Less</label>
                                        <textarea name="regular_less"
                                            class="form-control"
                                            rows="2">{{ $product->regular_less }}</textarea>
                                    </div>
                                    <div class="row g-3 mt-2">
                                        <div class="col-md-3">
                                            <label>Serial Number</label>
                                            <input type="text" name="serial_number" class="form-control" value="{{ $product->serial_number }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label>Category</label>
                                            <select name="category_id" class="form-control" required>
                                                <option value="">--Select--</option>
                                                @foreach ($categories as $category)
                                                    <option value="{{ $category->id }}" {{ $product->category_id == $category->id ? 'selected' : '' }}>
                                                        {{ $category->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label>Model</label>
                                            <input type="text" name="model" class="form-control" value="{{ $product->model }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label>Unit</label>
                                            <select name="unit_id" class="form-control">
                                                <option>--Select--</option>
                                                @foreach($units as $unit)
                                                    <option value="{{$unit->id}}" {{ $product->unit_id == $unit->id ? 'selected' : '' }}>
                                                        {{$unit->name}}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Stock Section -->
                        <div class="card mb-4 shadow-sm">
                            <div class="card-header bg-dark text-white">
                                <h5 class="mb-0">Stock Information</h5>
                            </div>
                            <div class="card-body row g-3">
                                <div class="col-md-2">
                                    <label>Initial Quantity</label>
                                    <input type="number" name="quantity" class="form-control" value="{{ $product->quantity }}">
                                </div>
                                <div class="col-md-2">
                                    <label>Remaining Stock</label>
                                    <input type="number" name="remaining_stock" class="form-control" value="{{ $product->remaining_stock }}" readonly>
                                </div>
                                <div class="col-md-2">
                                    <label>Selling Price</label>
                                    <input type="number" step="0.01" name="sales_price" class="form-control" value="{{ $product->sales_price }}" required>
                                </div>
                                <div class="col-md-3 d-flex align-items-center">
                                    <label class="me-2">Status: </label>
                                    <span class="badge 
                                        @if($product->status == 'In Stock') bg-success
                                        @elseif($product->status == 'Low Stock') bg-warning
                                        @else bg-danger
                                        @endif">
                                        {{ $product->status }}
                                    </span>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="control-label">Discount</label>
                                    <select name="tax_id" class="form-control">
                                        <option value="0">---Select Discount---</option>
                                        @foreach($taxes as $tax)
                                            <option value="{{$tax->id}}" {{ $product->tax_id == $tax->id ? 'selected' : '' }}>
                                                {{$tax->name}} %
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('tax_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="card mt-4">
                            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Adjustments</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-sm" id="adjustmentTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Adjustment</th>
                                            <th>Adjustment Status</th>
                                            <th>Remarks</th>
                                            <th>New Initial Qty</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if($product->adjustments && $product->adjustments->count() > 0)
                                            @foreach($product->adjustments as $adj)
                                                <tr>
                                                    <td>
                                                        <input type="number" name="adjustment[]" class="form-control adjustment" 
                                                            value="{{ $adj->adjustment }}" min="0">
                                                    </td>
                                                    <td>
                                                        <select name="adjustment_status[]" class="form-control">
                                                            <option value="Return" {{ $adj->adjustment_status == 'Return' ? 'selected' : '' }}>Return</option>
                                                            <option value="Others" {{ $adj->adjustment_status == 'Others' ? 'selected' : '' }}>Others</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="adjustment_remarks[]" class="form-control" 
                                                            placeholder="Enter remarks" value="{{ $adj->remarks }}">
                                                    </td>
                                                    <td>
                                                        <input type="number" name="new_initial_qty[]" class="form-control new-initial-qty" 
                                                            value="{{ $adj->new_initial_qty }}" readonly>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td>
                                                    <input type="number" name="adjustment[]" class="form-control adjustment" value="0" min="0">
                                                </td>
                                                <td>
                                                    <select name="adjustment_status[]" class="form-control">
                                                        <option value="Return">Return</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="adjustment_remarks[]" class="form-control" placeholder="Enter remarks">
                                                </td>
                                                <td>
                                                    <input type="number" name="new_initial_qty[]" class="form-control new-initial-qty" readonly>
                                                </td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Supplier Section -->
                        <div class="card shadow-sm">
                            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Supplier Details</h5>
                                <button type="button" class="btn btn-sm btn-success add_button">
                                    <i class="fa fa-plus"></i> Add Supplier
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="field_wrapper">
                                    @if ($product->productSuppliers && count($product->productSuppliers) > 0)
                                        @foreach ($product->productSuppliers as $supplierItem)
                                            <div class="row mb-2">
                                                <div class="col-md-5">
                                                    <input type="text" class="form-control" value="{{ $supplierItem->supplier->name ?? '' }}" readonly>
                                                    <input type="hidden" name="supplier_id[]" value="{{ $supplierItem->supplier_id }}">
                                                </div>
                                                <div class="col-md-5">
                                                    <input type="number" name="supplier_price[]" class="form-control" 
                                                        placeholder="Purchase Price" value="{{ $supplierItem->price }}" required>
                                                </div>
                                                <div class="col-md-2 d-flex align-items-center">
                                                    <button type="button" class="btn btn-danger remove-supplier">Delete</button>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>

                        <!-- Submit -->
                        <div class="text-end mt-4">
                            <button type="submit" class="btn btn-success px-4">
                                <i class="fa fa-save"></i> Update Product
                            </button>
                            <a href="{{ route('product.index') }}" class="btn btn-secondary px-4">
                                <i class="fa fa-times"></i> Cancel
                            </a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection


@push('js')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
    const suppliers = @json($suppliers);
    $(document).ready(function () {
        var maxField = 10;
        var addButton = $('.add_button');
        var wrapper = $('.field_wrapper');
        var x = {{ count($product->productSuppliers ?? []) }};

        // Function to generate supplier select options
        function generateSupplierOptions() {
            let options = '<option value="">Select Supplier</option>';
            suppliers.forEach(function (sup) {
                options += `<option value="${sup.id}">${sup.name}</option>`;
            });
            return options;
        }

        // Function to return new row HTML
        function getFieldHTML() {
            return `
                <div class="row mb-2">
                    <div class="col-md-5">
                        <select name="supplier_id[]" class="form-control" required>
                            ${generateSupplierOptions()}
                        </select>
                    </div>
                    <div class="col-md-5">
                        <input type="number" name="supplier_price[]" class="form-control" placeholder="Purchase Price" required>
                    </div>
                    <div class="col-md-2 d-flex align-items-center">
                        <button type="button" class="btn btn-danger remove-supplier">Delete</button>
                    </div>
                </div>
            `;
        }

        // Add new supplier row
        $(addButton).click(function () {
            if (x < maxField) {
                x++;
                $(wrapper).append(getFieldHTML());
            }
        });

        // Remove supplier row
        $(wrapper).on('click', '.remove-supplier', function (e) {
            e.preventDefault();
            $(this).closest('.row').remove();
            x--;
        });
       
       // Select inputs using jQuery
        const $initialStockInput = $('input[name="quantity"]');
        const $remainingStockInput = $('input[name="remaining_stock"]');

        // Function to update New Initial Qty for a row
        function updateRowNewQty($row) {
            const remainingStock = parseFloat($remainingStockInput.val()) || 0;
            const adjustment = parseFloat($row.find('.adjustment').val()) || 0;
            const newInitialQty = remainingStock + adjustment;
            $row.find('.new-initial-qty').val(newInitialQty);
        }

        // Initialize all adjustment rows on page load
        $('#adjustmentTable tbody tr').each(function() {
            updateRowNewQty($(this));
        });

        // When initial quantity changes
        $initialStockInput.on('input', function() {
            const initialVal = parseFloat($(this).val()) || 0;
            $remainingStockInput.val(initialVal);

            // Update all adjustment rows
            $('#adjustmentTable tbody tr').each(function() {
                updateRowNewQty($(this));
            });

            // Update product status badge
            const threshold = initialVal <= 10 ? 1 : Math.floor(initialVal * 0.2);
            let status = 'In Stock';
            if (initialVal === 0) status = 'Out of Stock';
            else if (initialVal <= threshold) status = 'Low Stock';

            const $badge = $('.badge');
            $badge.text(status).removeClass('bg-success bg-warning bg-danger');

            if (status === 'In Stock') $badge.addClass('bg-success');
            else if (status === 'Low Stock') $badge.addClass('bg-warning');
            else if (status === 'Out of Stock') $badge.addClass('bg-danger');
        });

        // When adjustment input changes
        $('#adjustmentTable').on('input', '.adjustment', function() {
            const $row = $(this).closest('tr');
            updateRowNewQty($row);
        });

        // initialize on page load
        updateRemainingStock();
        
        // Product suggestions (autocomplete)
        $("#product_name").on("keyup", function () {
            let query = $(this).val();
            if (query.length > 1) {
                $.ajax({
                    url: "{{ route('products.suggest') }}",
                    type: "GET",
                    data: { query: query },
                    dataType: "json",
                    success: function (data) {
                        console.log("RAW DATA:", data);
                        console.log("IS ARRAY:", Array.isArray(data));

                        let suggestions = "";
                        let list = Array.isArray(data) ? data : data.items;

                        if (!list) {
                            console.error("No array found in response:", data);
                            return;
                        }

                        list.forEach(function (item) {
                            suggestions += `<a href="#" class="list-group-item list-group-item-action product-suggestion"
                                                data-code="${item.item_code}" 
                                                data-name="${item.item_description}">
                                                ${item.item_code} - ${item.item_description}
                                            </a>`;
                        });

                        $("#productSuggestions").html(suggestions).show();
                    },
                    error: function (xhr) {
                        console.error("AJAX Error:", xhr.responseText);
                    }
                });
            } else {
                $("#productSuggestions").hide();
            }
        });

        $(document).on("click", ".product-suggestion", function (e) {
            e.preventDefault();

            let code = $(this).data("code");
            let name = $(this).data("name");

            $("#product_name").val(name);
            $("#supplier_product_code").val(code);
            $("#productSuggestions").hide();

            $.ajax({
                url: "{{ route('products.suppliers') }}",
                type: "GET",
                data: { item_code: code },
                success: function (data) {
                    console.log("Suppliers:", data); // 🔹 Check in console

                    if (Array.isArray(data) && data.length > 0) {
                        let supplier = data[0]; // just take first one
                        $("#supplier_id").val(supplier.id);
                        $("#supplier_name").val(supplier.name);
                        $("#supplier_price").val(supplier.item_price);
                    } else {
                        alert("No suppliers found for this product");
                    }
                },
                error: function (xhr) {
                    console.error("Supplier AJAX Error:", xhr.responseText);
                }
            });
        });
    });
</script>
@endpush
