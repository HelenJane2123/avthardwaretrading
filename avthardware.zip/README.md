# avthardware_trading

Additional plugins: 
For excel: composer require phpoffice/phpspreadsheet
For philippine brgy, municipality and city: npm install philippine-location-json-for-geer
For pdf: composer require barryvdh/laravel-dompdf
php artisan vendor:publish --provider="Barryvdh\DomPDF\ServiceProvider"